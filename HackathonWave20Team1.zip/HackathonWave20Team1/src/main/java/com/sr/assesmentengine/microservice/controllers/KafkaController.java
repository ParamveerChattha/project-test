package com.sr.assesmentengine.microservice.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sr.assesmentengine.microservice.message.KafkaProducer;
import com.sr.assesmentengine.microservice.message.MessageStorage;



@RestController
@RequestMapping(value="/kafka")
public class KafkaController {
	@Autowired
	KafkaProducer producer;
	
	@Autowired
	MessageStorage storage;
	
	@GetMapping(value="/producer")
	public String producer(@RequestParam("data")String data){
		try {
		producer.send(data);
		
		return "Done";
		}
		catch(Exception e)
		{
			return "Kafka is temporarily unavailable";
		}
	}
	
	@GetMapping(value="/consumer")
	public String getAllRecievedMessage(){
		String messages = storage.toString();
		//storage.clear();
		
		return messages;
	}

}
