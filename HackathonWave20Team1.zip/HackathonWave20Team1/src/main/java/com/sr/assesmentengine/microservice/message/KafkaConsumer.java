package com.sr.assesmentengine.microservice.message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.sr.assesmentengine.microservice.exceptions.KafkaUnavialableException;



@Service
public class KafkaConsumer {
	private static final Logger log = LoggerFactory.getLogger(KafkaConsumer.class);

	@Autowired
	MessageStorage storage;
	
	@KafkaListener(topics="${topic}")
    public void processMessage(String message) throws KafkaUnavialableException{
		log.info("received content = '{}'", message);
		try {
		storage.put(message);
		}
		 catch(Exception ex) {
		    	throw new KafkaUnavialableException("Kafka is temporarily unavailable");
		    }
    }
}
