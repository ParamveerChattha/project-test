package com.sr.assesmentengine.microservice.exceptions;

public class KafkaUnavialableException extends Exception{
	public KafkaUnavialableException(String message) {
		// TODO Auto-generated constructor stub
	
		super(message);
	}

}
