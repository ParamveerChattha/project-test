package com.sr.assesmentengine.microservice.logger;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;


public class MyLogger {
    private Logger logger =  LogManager.getLogger("HackathonWave20Team1Application.class");
}