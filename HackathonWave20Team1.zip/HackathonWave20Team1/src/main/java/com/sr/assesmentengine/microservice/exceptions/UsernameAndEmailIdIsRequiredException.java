package com.sr.assesmentengine.microservice.exceptions;

public class UsernameAndEmailIdIsRequiredException  extends Exception{
	public UsernameAndEmailIdIsRequiredException(String message)
	{
		super(message);
	}

}
